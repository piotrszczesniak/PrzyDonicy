jQuery(document).ready(function () {

  // scroll effect on navbar
  jQuery(window).on("scroll", function () {
    if (jQuery(window).scrollTop()) {
      jQuery('nav').addClass('nav-white');
    } else {
      jQuery('nav').removeClass('nav-white');
    }
  })
})

jQuery(document).ready(function () {
  jQuery(window).scroll(function () {
    if (jQuery(this).scrollTop() > 50) {
      jQuery('#back-to-top').show();
    } else {
      jQuery('#back-to-top').hide();
    }
  });
  // scroll body to 0px on click
  jQuery('#back-to-top').click(function () {
    jQuery('body,html').animate({
      scrollTop: 0
    }, 400);
    return false;
  });
});